<?php
// include 'models/myShoppingCart.php';
// include_once 'models/orderModel.php';
include 'lib/abstractController.php';
include 'lib/view.php';
include 'lib/tableView.php';
class CheckoutController extends AbstractController {
	private $context;
	private $subviewTemplate;
	public function __construct($context) {
		parent::__construct ( $context );
		$this->context = $context;
	}
	protected function getView($isPostback) {
		$cart = new ShoppingCart ( $this->context );
		// testing only
		$cart->delete ();
		$cart = new ShoppingCart ( $this->context );
		
		$cart->addItem ( new ShoppingCartItem ( 1, 20, 45.95 ) );
		$cart->addItem ( new ShoppingCartItem ( 1, 10, 45.95 ) );
		
		$cart->setCustomerId ( 1 ); // tests data
		                         // end test patches
		
		$uri = $this->getURI ();
		$action = $uri->getPart ();
		switch ($action) {
			case '' :
				return $this->handleBlank ( $isPostback );
			case 'delivery' :
				// $this->subviewTemplate = $this->getTemplateForEdit();
				return $this->handleDelivery ( $isPostback, $uri->getID () );
			case 'payment' :
				// $this->subviewTemplate = $this->getTemplateForView();
				return $this->handlePayment ( $isPostback, $uri->getID () );
			case 'final' :
				// $this->subviewTemplate = $this->getTemplateForDelete();
				return $this->processOrder ( $isPostback );
			default :
				throw new InvalidRequestException ( "Invalid action in URI" );
		}
	}
	public function handleBlank($postback, $id = null) {
		if (! $postback) {
			// display cart has a link to /deliver
			return $this->createShoppingCartView ( $id ); // form with data from DB (or blank if ID null)
		}
	}
	// display cart
	// return 'html/productPanel.html';
	// user confirms they want to purchase (link to /delivery
	public function handleDelivery($isPostback, $uri) {
		// if not postbnack, display form
		// if postback, get post data, create customer, save id, redirect to final
		return $this->createDeliveryView ( $id );
	}
	public function handlePayment() {
	//skipping this function
	}
	public function processOrder() {
		$cart = new ShoppingCart ( $this->getContext () );
		OrderModel::createFromCart ( $this->context->getDB (), $cart );
		$cart->delete ();
	}
	protected function getPagename() {
		return 'checkout';
	}
	private function createShoppingCartView() {
		$db = $this->getDB ();
		$view = new View ( $this->getContext () );
		                                           // $cart = new ShoppingCart($this->context);//uncomment ne
		$view = new View ( $this->getContext () );
		$view->setTemplate ( 'html/forms/checkout.html' );
		$view->setTemplateField ( 'pagename', $this->getPagename () );
		$view->setSubviewTemplate ( 'html//forms/checkout.html' );
		//$view->setSubviewField ( "name", $product->getProductName () );
		//$view->setSubviewField ( "id", $id );
		
		//$view->setSubviewTemplate ( $this->subviewTemplate );
		
		return $view;
	}
	private function createDeliveryView($id) {
		
		$view = new View ( $this->getContext () );
		$view->setModel ( null );
		$view->setTemplate ( 'html/masterPage.html' );
		$view->setTemplateField ( 'pagename', 'Products' );
		$view->addContent ( $html );
		return $view;
	
	}
	private function createFinalView($id) {
		$view = new View ( $this->getContext () );
		$view->setTemplate ( 'html/productPanel.html' );
		$view->setTemplateField ( 'pagename', $this->getPagename () );
		$view->setSubviewTemplate ( $this->subviewTemplate );
		
		return $view;
	}
}
?>