
<?php

/*
 * so lets get started with controller based on ML controllers sample available on moodle the uri /patterns deal t int his controller /shoppingCart/new
 */
include 'lib/AbstractController.php';
include 'lib/view.php';
// include 'lib/tableView.php';
include 'models/product.php';
// include 'models/shoppingCart.php';
class ShoppingCartController extends AbstractController {
	private $context;
	private $subviewTemplate;
	public function __construct($context) {
		parent::__construct ( $context );
		$this->context = $context;
	}
	public function handleDelete() {
		$cart = new ShoppingCart ( $this->context );
		$cart = $cart->delete ();
	}
	protected function getView($isPostback) {
		$uri = $this->getURI ();
		$action = $uri->getPart ();
		switch ($action) {
			case 'add' :
				return $this->handleAdd ( $isPostback, $uri->getID () );
			
			case '' :
			
			case 'view' :
				return $this->handleView ( $isPostback );
			
			case 'delete' :
				return $this->handleDelete ( $isPostback, $uri->getID () );
			
			default :
				throw new InvalidRequestException ( "Invalid action in URI" );
		}
	}
	public function handleView($postback, $id = null) {
		// return $this->createView($id);
		$db = $this->getDB ();
		//$product= new Product();
		
		$view = new View ( $this->getContext () );
		$view->setTemplate ( 'html/masterPage.html' );
		$view->setTemplateField ( 'pagename', 'Cart' );
		$cart = new ShoppingCart ( $this->getContext () );
		//var_dump($cart);
		$html = '';
		$count = $cart->getCount ();
		echo "The cart has $count items<br/>";
		for($i = 0; $i < $count; $i ++) {
			$item = $cart->getItemAt ( $i );
			//var_dump ( $item );
			$productID = $item->getItemCode ();
			$quantity = $item->getQuantity ();
			$total = $item->getTotal ();
			echo $total;
			$product = new ProductModel($db,$productID);
			$name = $product->getProductName();
			echo $name;
			$html .= "Product $productID  is $name,  $quantity, $total <br/> ";
	
		}
		
		$view->addContent ( $html );
		
		return $view;
	}
	public function handleAdd($postback, $id = null) {
		if (! $postback) {
			return $this->createView ( $id ); // form with data from DB (or blank if ID null)
		} else {
			
			return $this->getFormData ( $id );
		}
	}
	protected function getFormData($id) {
		$quantity = $this->getInput( 'quantity' );
			echo "Quantity is $quantity<br/>";
		$cart = new ShoppingCart ( $this->context );
		$db = $this->getDB ();
		$product = new ProductModel ( $db, $id );
		$price = $product->getProductPrice ();
		$this->productPrice = $product->getProductPrice ();
		$item = new ShoppingCartItem ( $id, $quantity, $price );
		$cart->addItem ( $item );
	    //var_dump($cart);
	//	$cart->save();
		$this->redirectTo ( "productsViewer");
		
		return null;
	}
	public function createView($id) { // allows user to view product selected
		$db = $this->getDB ();
		
		$view = new View ( $this->getContext () );
		$product = new ProductModel ( $db, $id );
		$productPrice = $product->getProductPrice ();
		$this->productPrice = $product->getProductPrice ();
		$view->setTemplate ( 'html/masterPage.html' );
		$view->setTemplateField ( 'pagename', $this->getPagename () );
		$view->setSubviewTemplate ( 'html/shoppingCart.html' );
		$view->setSubviewField ( "name", $product->getProductName () );
		$view->setSubviewField ( "id", $id );
		$view->setSubviewField ( "price", $product->getProductPrice () );
		
		return $view;
	}
	protected function getPagename() {
		return 'Cart';
	}
}
?>